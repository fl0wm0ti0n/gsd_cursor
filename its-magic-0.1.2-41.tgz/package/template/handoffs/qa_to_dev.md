# QA -> Dev Handoff

## Findings

## Required fixes
